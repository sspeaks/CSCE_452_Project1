/****************************************************************************

Subwindow Control Scheme.

-----------------------------------------------------------------------

Trevor Barnett

****************************************************************************/

//*************************************************************************
//
//  File Name: GLUI SubWindow Template
//  Author   : Ali Baderedine
//  
//  Description:
//  
//*************************************************************************

#include <gl/glut.h>
#include <gl/glui.h>
#include <vector>
#include <cmath>
#include <stdlib.h>
#include <iostream>

#define PI 3.14159

static int shoulder = 0, elbow = 0, head = 0;
int randcount = 0;
GLfloat size = .1;
GLfloat mat[16];
GLfloat mat2[16];
GLfloat mat3[16];


//  define the window position on screen
int window_X_position;
int window_Y_position;

//  variables representing the window size
int window_width = 750;
int window_height = 750;

//  variable representing the window title
char *window_title = "Painting Robot Arm";

//  The id of the main window
GLuint main_window;

//  pointer to a GLUI window
GLUI * glui_subwindow;

//  The x and y coordinates of the glui window
int glui_subwindow_x, glui_subwindow_y;

//  Declare live variables (related to GLUI)
int draw = 0;

//  Declare callbacks related to GLUI
void glui_callback(int arg);
void glui_callback2(int arg);
void glui_callback3(int arg);
void glui_callback4(int arg);
void glui_callback5(int arg);
void glui_callback6(int arg);
void glui_callback7(int arg);
void glui_callback8(int arg);

//  Tells whether to display the window full screen or not
int fullScreen = 0;

void init(void);
void display(void);
void reshape(int w, int h);
void mouse(int button, int state, int x, int y);
void keyboard(unsigned char key, int x, int y);

void setupGLUI();

//  This function centers your window on the screen
void centerOnScreen(void);

bool calc = false;
bool inLoop = false;
std::vector<double> v(1, -10000);

void init(void)
{
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glShadeModel(GL_FLAT);
}

void squareBrush(float x, float y)
{
	float p1[3] = { x + (.75*size), y + (.75*size), 0 };
	float p2[3] = { x + (.75*size), y - (.75*size), 0 };
	float p4[3] = { x - (.75*size), y + (.75*size), 0 };
	float p3[3] = { x - (.75*size), y - (.75*size), 0 };
	glBegin(GL_POLYGON);
	glVertex3fv(p1);
	glVertex3fv(p2);
	glVertex3fv(p3);
	glVertex3fv(p4);
	glEnd();
	glFlush();
}

void circle(double x, double y)
{
	int radius = 1;
	double i = 0;
	double changeInAngle = 0.01;
	glBegin(GL_POLYGON);
	for (i = 0; i < 2 * PI; i += 0.01){
		glVertex3f((x + cos(i)*radius), (y + sin(i)*radius), 0.0);
	}
	glEnd();
}

void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT);

	GLdouble MyMatrix[16];

	glMatrixMode(GL_MODELVIEW_MATRIX);

	glPushMatrix();

	//joint 1
	glRotatef((GLfloat)shoulder, 0.0, 0.0, 1.0);
	glTranslatef(0.0, 1.0, 0.0);
	glPushMatrix();
	glScalef(0.2, 1.5, 0);
	glGetFloatv(GL_MODELVIEW_MATRIX, mat);
	glutSolidCube(1.0);
	glPopMatrix();

	//joint 2
	glTranslatef(0.0, 0.6250, 0.0);
	glRotatef((GLfloat)elbow, 0.0, 0.0, 1.0);
	glTranslatef(0.0, 0.6250, 0.0);
	glPushMatrix();
	glScalef(0.2, 1.0, 0);
	glGetFloatv(GL_MODELVIEW_MATRIX, mat2);
	glutSolidCube(1.0);
	glPopMatrix();

	//3
	glTranslatef(0.0, 0.43750, 0.0);
	glRotatef((GLfloat)head, 0.0, 0.0, 1.0);
	glTranslatef(0.0, 0.43750, 0.0);
	glPushMatrix();
	glScalef(0.2, 0.75, 0);
	glGetFloatv(GL_MODELVIEW_MATRIX, mat3);
	glutSolidCube(1.0);
	glPopMatrix();
	glPopMatrix();

	if (calc)
	{
		int spot = 0;
		while (v.at(spot) != -10000)
			spot++;
		if (v.size() - spot <= 2)
			v.resize(v.size() + 2, -10000);
		v[spot] = mat[4] + mat2[4] + mat3[4];
		spot++;
		v[spot] = mat[5] + mat2[5] + mat3[5];

		calc = false;
	}
	//squareBrush((mat[4] + mat2[4] + mat3[4]), (mat[5] + mat2[5] + mat3[5]));

	int count = 0;
	double x_1, y_1;
	while (v.at(count) != -10000)
	{
		x_1 = v.at(count);
		count++;
		y_1 = v.at(count);
		count++;
		squareBrush(x_1, y_1);
	}


	glutSwapBuffers();
}



void keyboard(unsigned char key, int x, int y)
{
}

void reshape(int w, int h)
{
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(80.0, (GLfloat)w / (GLfloat)h, 1.0, 20.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatef(0.0, 0.0, -5.0);
}

void mouse(int button, int state, int x, int y)
{

}


void setupGLUI()
{
	//  Register keyboard, mouse, special, and reshape callbacks of your graphics window
	GLUI_Master.set_glutKeyboardFunc(keyboard);
	GLUI_Master.set_glutMouseFunc(mouse);
	GLUI_Master.set_glutReshapeFunc(reshape);

	GLUI_Master.set_glutIdleFunc(NULL);

	// ***** Define glui subwindow (s) *****/

	//  create glui sun window
	glui_subwindow = GLUI_Master.create_glui_subwindow(main_window, GLUI_SUBWINDOW_RIGHT);

	//  Let each GLUI window you've created know where its main graphics window is
	glui_subwindow->set_main_gfx_window(main_window);

	//  Add controls to the GLUI subwindow
	glui_subwindow->add_button("Joint 1 Left", 0, glui_callback);
	glui_subwindow->add_button("Joint 1 Right", 1, glui_callback2);
	glui_subwindow->add_button("Joint 2 Left", 2, glui_callback3);
	glui_subwindow->add_button("Joint 2 Right", 3, glui_callback4);
	glui_subwindow->add_button("Joint 3 Left", 4, glui_callback5);
	glui_subwindow->add_button("Joint 3 Right", 5, glui_callback6);
	glui_subwindow->add_button("Paint", 6, glui_callback7);
	glui_subwindow->add_button("Quit", 7, glui_callback8);

	// ***** End of Define glui subwindow (s) *****/
}

void glui_callback(int arg)
{
	shoulder = (shoulder + 1) % 360;
	glutPostRedisplay();
}
void glui_callback2(int arg)
{
	shoulder = (shoulder - 1) % 360;
	glutPostRedisplay();
}
void glui_callback3(int arg)
{
	elbow = (elbow + 1) % 360;
	glutPostRedisplay();
}
void glui_callback4(int arg)
{
	elbow = (elbow - 1) % 360;
	glutPostRedisplay();
}
void glui_callback5(int arg)
{
	head = (head + 1) % 360;
	glutPostRedisplay();
}
void glui_callback6(int arg)
{
	head = (head - 1) % 360;
	glutPostRedisplay();
}
void glui_callback7(int arg)
{
	calc = true;
	glutPostRedisplay();
}
void glui_callback8(int arg)
{
	exit(1);
}

void centerOnScreen(void)
{
	//  Set the window position such that the window becomes centered
	window_X_position = (glutGet(GLUT_SCREEN_WIDTH) - window_width) / 2;
	window_Y_position = (glutGet(GLUT_SCREEN_HEIGHT) - window_height) / 2;
}

void main(int argc, char **argv)
{
	//centerOnScreen();

	glutInit(&argc, argv);
	glutInitWindowSize(window_width, window_height);
	glutInitWindowPosition(window_X_position, window_Y_position);
	glutInitDisplayMode(GLUT_DOUBLE |GLUT_RGB);
	main_window = glutCreateWindow(window_title);

	//  Initialize stuff that remain constant throughout the
	//  program.
	init();

	if (fullScreen)
		glutFullScreen();

	// Set the display function
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);

	//  Setup all glui stuff
	setupGLUI();
	
	glutMainLoop();

}
